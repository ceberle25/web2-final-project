# Web 2 Final Project

A Node.js/Express blog application that converts Markdown files to HTML with a contact form.

## Features
- Dynamic blog posts from Markdown files
- Email contact form
- EJS templating
- Prism.js syntax highlighting

## Installation
```bash